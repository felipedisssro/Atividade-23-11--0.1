# Blog com CodeIgniter 4

Este projeto parte do `aula0911.zip` do professor. Os arquivos de cursos foram mantidos como referência, e o blog segue o mesmo padrão de Model, Controller, rotas e views. A atividade mostrada é em **PHP**, mesmo que você esteja estudando Java em paralelo.

## Como instalar e executar

1. Instale PHP 8.2 ou superior (com extensões `intl`, `mbstring` e `mysqli`), Composer e MySQL. O projeto original já inclui `composer.json` e `composer.lock`.
2. Abra um terminal dentro da pasta `aula0911` e execute:

   ```bash
   composer install
   ```

3. No phpMyAdmin, execute o arquivo `blog.sql`. Ele cria o mesmo banco `aula0911` usado pelo professor e acrescenta a tabela `posts`. Se quiser três publicações para experimentar, execute `posts-exemplo.sql` uma única vez depois. A antiga tabela `cursos` não é necessária para o blog.
4. Confira no arquivo `.env` os parâmetros `database.default.hostname`, `database.default.database`, `database.default.username`, `database.default.password` e `database.default.port` de acordo com seu MySQL. O endereço padrão do professor é `http://localhost:8080/`.
5. Execute, ainda na pasta do projeto:

   ```bash
   php spark serve
   ```

## Endereços

- `http://localhost:8080/` — dez publicações mais recentes, com título e link.
- `http://localhost:8080/post/1` — conteúdo completo de uma publicação (troque `1` pelo ID).
- `http://localhost:8080/painel/posts` — lista para cadastrar, editar e excluir publicações.
- Abra `previa.html` com dois cliques para ver o visual da página inicial e do painel mesmo antes de instalar PHP. Essa prévia mostra exemplos fixos; os formulários reais ficam no endereço acima.

## Onde está cada parte

- `app/Models/PostModel.php`: tabela, campos aceitos e validação.
- `app/Controllers/Posts.php`: cadastro, edição, exclusão e listagem no painel.
- `app/Controllers/Home.php`: página inicial e publicação completa.
- `app/Config/Routes.php`: caminhos das páginas.
- `app/Views/blog_inicio.php`, `blog_post.php`, `posts.php`, `posts_form.php`: telas.
- `public/blog.css`: estilo visual do blog. O `public/styles.css` original dos cursos foi preservado.
- `blog.sql`: estrutura do banco de dados; `posts-exemplo.sql`: dados de exemplo opcionais.

## Relação com as aulas anteriores

O professor já usava `CursoModel`, `Cursos`, `cursos.php`, `cursos_form.php` e rotas `cursos/inserir` e `cursos/editar/(:num)`. O blog repete essa organização com `PostModel`, `Posts`, `posts.php` e `posts_form.php`. Para a página pública, `Home` consulta os posts e entrega os dados para `blog_inicio.php` e `blog_post.php`. O HTML e CSS são mais caprichados, mas o funcionamento continua usando os conceitos básicos mostrados no projeto original.

**Observação:** o painel não tem login porque o enunciado não pede autenticação. Use o projeto apenas em ambiente local/de estudo; se quiser publicar na internet, adicione autenticação antes.
