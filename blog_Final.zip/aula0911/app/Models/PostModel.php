<?php

namespace App\Models;

use CodeIgniter\Model;

class PostModel extends Model
{
    protected $table            = 'posts';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['titulo', 'conteudo'];
    protected $useTimestamps    = false;

    protected $validationRules = [
        'titulo'   => 'required|min_length[3]|max_length[150]',
        'conteudo' => 'required|min_length[3]',
    ];
}
