<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;

class Posts extends BaseController
{
    public function index()
    {
        $postModel = model('PostModel');
        $dados['posts'] = $postModel->orderBy('criado_em', 'DESC')->orderBy('id', 'DESC')->findAll();
        return view('posts', $dados);
    }

    public function inserir()
    {
        $dados['msg'] = '';
        $dados['post'] = null;

        if ($this->request->is('post')) {
            $postModel = model('PostModel');
            $dadosPost = [
                'titulo'   => $this->request->getPost('titulo'),
                'conteudo' => $this->request->getPost('conteudo'),
            ];

            if ($postModel->insert($dadosPost)) {
                return redirect()->to('painel/posts');
            }

            $dados['msg'] = implode(' ', $postModel->errors()) ?: 'Erro ao salvar publicação.';
            $dados['post'] = (object) $dadosPost;
        }

        return view('posts_form', $dados);
    }

    public function editar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);
        $dados['msg'] = '';

        if (!$dados['post']) {
            throw PageNotFoundException::forPageNotFound();
        }

        if ($this->request->is('post')) {
            $dadosPost = [
                'titulo'   => $this->request->getPost('titulo'),
                'conteudo' => $this->request->getPost('conteudo'),
            ];

            if ($postModel->update($id, $dadosPost)) {
                return redirect()->to('painel/posts');
            }

            $dados['msg'] = implode(' ', $postModel->errors()) ?: 'Erro ao salvar publicação.';
            $dados['post'] = (object) array_merge((array) $dados['post'], $dadosPost);
        }

        return view('posts_form', $dados);
    }

    public function excluir($id)
    {
        $postModel = model('PostModel');

        if (!$postModel->find($id)) {
            throw PageNotFoundException::forPageNotFound();
        }

        $postModel->delete($id);
        return redirect()->to('painel/posts');
    }
}
