<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Cursos extends BaseController
{
    public function index()
    {
        $cursoModel = model('CursoModel');
        //recuperar todos os cursos cadastrados na tabela
        $dados['cursos'] = $cursoModel->findAll();

        //passa a lista de cursos para a view
        return view('cursos', $dados);
    }

    public function inserir() 
    {
        $dados['msg'] = "";
        
        //verifica se foi feita uma requisição POST
        if($this->request->is('post')) {
            $cursoModel = model('CursoModel');
            $dadosCurso = $this->request->getPost(); //dados submetidos no form

            if($cursoModel->insert($dadosCurso)) {
                //sucesso. redireciona para a lista de cursos
                return redirect()->to('cursos');
            } else {
                //erro
                $dados['msg'] = "Erro ao salvar curso";
            }

        }
        return view('cursos_form', $dados);
    }

    public function editar($id) 
    {
        $cursoModel = model("CursoModel");
        $dados['curso'] = $cursoModel->find($id);
        $dados['msg'] = '';

        //verifica se foi feita uma requisição POST
        if($this->request->is('post')) {
            $dadosCurso = $this->request->getPost(); //dados submetidos no form

            if($cursoModel->update($id, $dadosCurso)) {
                //sucesso. redireciona para a lista de cursos
                return redirect()->to('cursos');
            } else {
                //erro
                $dados['msg'] = "Erro ao salvar curso";
            }

        }

        return view('cursos_form', $dados);
    }

    public function excluir($id) 
    {
        $cursoModel = model("CursoModel");
        $cursoModel->delete($id);
        return redirect()->to('cursos');
    }

    public function teste()
    {
        $cursoModel = new \App\Models\CursoModel();
        $novoCurso = [
            'nomecurso' => "Java para Iniciantes",
            'duracao'   => 8
        ];
        if($cursoModel->insert($novoCurso)) {
            echo 'Curso salvo com sucesso!';
        } else {
            echo 'Erro ao salvar curso <br />';
            print_r($cursoModel->errors());
        }
    }
}
