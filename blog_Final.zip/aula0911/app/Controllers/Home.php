<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        $postModel = model('PostModel');
        $dados['posts'] = $postModel->orderBy('criado_em', 'DESC')->orderBy('id', 'DESC')->findAll(10);
        return view('blog_inicio', $dados);
    }

    public function post($id): string
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);

        if (!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('blog_post', $dados);
    }
}
