<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de posts | Caderno Aberto</title>
    <link rel="stylesheet" href="<?= base_url('blog.css') ?>">
</head>
<body>
    <header class="site-header"><div class="wrap header-content">
        <a class="brand" href="<?= base_url('/') ?>"><span class="brand-mark">✳</span> caderno<span>aberto</span></a>
        <nav aria-label="Navegação principal"><a href="<?= base_url('/') ?>">Ver blog</a><a class="nav-active" href="<?= base_url('painel/posts') ?>">Painel de posts</a></nav>
    </div></header>

    <main class="wrap panel-page">
        <p class="eyebrow">ÁREA DE GERENCIAMENTO</p>
        <div class="panel-heading"><div><h1>Suas publicações<span class="heading-dot">.</span></h1><p>Organize os textos que aparecem no blog.</p></div>
            <a class="button button-dark" href="<?= base_url('painel/posts/inserir') ?>">+ Nova publicação</a>
        </div>
        <div class="panel-card">
            <div class="panel-card-heading"><strong>Todos os posts</strong><span><?= count($posts) ?> <?= count($posts) === 1 ? 'publicação' : 'publicações' ?></span></div>
            <?php if (empty($posts)): ?>
                <div class="panel-empty"><span class="empty-icon">✎</span><h2>Nada publicado ainda</h2><p>Crie o primeiro post para começar o blog.</p></div>
            <?php else: ?>
                <div class="table-scroll"><table>
                    <thead><tr><th scope="col">PUBLICAÇÃO</th><th scope="col">DATA</th><th scope="col">AÇÕES</th></tr></thead>
                    <tbody>
                    <?php foreach ($posts as $post): ?>
                        <tr><td><span class="table-id">#<?= esc($post->id) ?></span> <a class="table-title" href="<?= base_url('post/' . $post->id) ?>"><?= esc($post->titulo) ?></a></td>
                            <td><time datetime="<?= esc(date('Y-m-d', strtotime($post->criado_em))) ?>"><?= esc(date('d/m/Y', strtotime($post->criado_em))) ?></time></td>
                            <td class="actions"><a class="action-edit" href="<?= base_url('painel/posts/editar/' . $post->id) ?>">Editar</a>
                                <form method="post" action="<?= base_url('painel/posts/excluir/' . $post->id) ?>" onsubmit="return confirm('Tem certeza que deseja excluir esta publicação?')">
                                    <?= csrf_field() ?><button class="action-delete" type="submit">Excluir</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            <?php endif; ?>
        </div>
        <a class="back-link" href="<?= base_url('/') ?>">← Voltar para o blog</a>
    </main>
    <footer class="site-footer"><div class="wrap footer-content"><strong>caderno<span>aberto</span> ✳</strong><span>Um blog para ideias que valem a leitura.</span></div></footer>
</body>
</html>
