<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($post->titulo) ?> | Caderno Aberto</title>
    <link rel="stylesheet" href="<?= base_url('blog.css') ?>">
</head>
<body>
    <header class="site-header"><div class="wrap header-content">
        <a class="brand" href="<?= base_url('/') ?>"><span class="brand-mark">✳</span> caderno<span>aberto</span></a>
        <nav aria-label="Navegação principal"><a href="<?= base_url('/') ?>">Início</a><a href="<?= base_url('painel/posts') ?>">Painel de posts <span aria-hidden="true">↗</span></a></nav>
    </div></header>

    <main class="wrap article-page">
        <a class="back-link" href="<?= base_url('/') ?>">← Voltar para as publicações</a>
        <article>
            <header class="article-header">
                <p class="eyebrow">PUBLICAÇÃO · <?= esc(str_pad((string) $post->id, 2, '0', STR_PAD_LEFT)) ?></p>
                <h1><?= esc($post->titulo) ?></h1>
                <p class="article-date">Publicado em <time datetime="<?= esc(date('Y-m-d', strtotime($post->criado_em))) ?>"><?= esc(date('d/m/Y', strtotime($post->criado_em))) ?></time></p>
            </header>
            <div class="article-content"><?= nl2br(esc($post->conteudo)) ?></div>
            <div class="article-end">✳ <span>Obrigado pela leitura.</span></div>
        </article>
        <a class="back-link" href="<?= base_url('/') ?>">← Ver outros posts</a>
    </main>

    <footer class="site-footer"><div class="wrap footer-content"><strong>caderno<span>aberto</span> ✳</strong><span>Um blog para ideias que valem a leitura.</span></div></footer>
</body>
</html>
