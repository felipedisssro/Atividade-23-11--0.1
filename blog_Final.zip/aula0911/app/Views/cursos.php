<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Cursos - Lista</title>
    <link rel="stylesheet" href="<?php echo base_url("styles.css") ?>">
</head>

<body>
    <header class="navbar">
        <nav class="nav-container">
            <a href="index.html" class="nav-brand">CursosApp</a>
            <ul class="nav-links">
                <li><a href="<?php echo base_url("cursos") ?>" class="active">Lista de Cursos</a></li>
                <li><a href="<?php echo base_url("cursos/inserir") ?>">Novo Curso</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <div class="page-header">
            <h1>Cursos Cadastrados</h1>
            <a href="<?php echo base_url("cursos/inserir") ?>" class="btn btn-primary">+ Novo Curso</a>
        </div>

        <div class="card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome do Curso</th>
                        <th>Duração em Horas</th>
                        <th class="actions-col">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cursos as $curso) : ?>
                    <tr>
                        <td><?php echo $curso->id ?></td>
                        <td><?php echo $curso->nomecurso ?></td>
                        <td><?php echo $curso->duracao ?>h</td>
                        <td class="actions-cell">
                            <a href="<?php echo base_url("cursos/editar/" . $curso->id) ?>" class="btn btn-edit">Editar</a>
                            <a href="<?php echo base_url("cursos/excluir/" . $curso->id) ?>" class="btn btn-delete">Excluir</a>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </main>
</body>

</html>