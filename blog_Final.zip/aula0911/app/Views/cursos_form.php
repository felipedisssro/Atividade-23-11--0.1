<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Cursos - Cadastro</title>
    <link rel="stylesheet" href="<?php echo base_url("styles.css") ?>">
</head>

<body>
    <header class="navbar">
        <nav class="nav-container">
            <a href="index.html" class="nav-brand">CursosApp</a>
            <ul class="nav-links">
                <li><a href="<?php echo base_url("cursos") ?>">Lista de Cursos</a></li>
                <li><a href="<?php echo base_url("cursos/inserir") ?>" class="active">Novo Curso</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <div class="page-header">
            <h1>Cadastrar Curso</h1>
        </div>

        <div class="card form-card">
            <p><?php echo $msg ?></p>
            <form method="POST">
                <div class="form-group">
                    <label for="nome">Nome do Curso</label>
                    <input type="text" id="nome" name="nomecurso" value="<?php echo $curso->nomecurso ?? '' ?>" placeholder="Ex: Desenvolvimento Web" required>
                </div>

                <div class="form-group">
                    <label for="duracao">Duração (em horas)</label>
                    <input type="number" id="duracao" name="duracao" value="<?php echo $curso->duracao ?? '' ?>" min="1" placeholder="Ex: 60" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </main>
</body>

</html>