<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caderno Aberto | Blog</title>
    <link rel="stylesheet" href="<?= base_url('blog.css') ?>">
</head>
<body>
    <header class="site-header">
        <div class="wrap header-content">
            <a class="brand" href="<?= base_url('/') ?>"><span class="brand-mark">✳</span> caderno<span>aberto</span></a>
            <nav aria-label="Navegação principal">
                <a class="nav-active" href="<?= base_url('/') ?>">Início</a>
                <a href="<?= base_url('painel/posts') ?>">Painel de posts <span aria-hidden="true">↗</span></a>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="wrap hero-content">
                <p class="eyebrow"><span class="status-dot"></span> UM ESPAÇO PARA COMPARTILHAR IDEIAS</p>
                <h1>Boas ideias merecem<br><em>ser compartilhadas.</em></h1>
                <p class="hero-description">Um lugar simples para escrever, publicar e descobrir novas histórias. Fique à vontade para explorar.</p>
                <a class="hero-link" href="#publicacoes">Explorar publicações <span aria-hidden="true">↘</span></a>
                <span class="hero-decoration" aria-hidden="true">✳</span>
            </div>
        </section>

        <section class="wrap listing" id="publicacoes">
            <div class="section-heading">
                <div><p class="eyebrow">LEITURA FRESQUINHA</p><h2>Últimas publicações<span class="heading-dot">.</span></h2></div>
                <span class="post-count"><?= count($posts) ?> <?= count($posts) === 1 ? 'post' : 'posts' ?></span>
            </div>

            <?php if (empty($posts)): ?>
                <div class="empty-state"><span class="empty-icon">✎</span><h3>Comece uma nova história</h3>
                    <p>Ainda não há posts por aqui. Cadastre a primeira publicação no painel.</p>
                    <a class="button button-dark" href="<?= base_url('painel/posts/inserir') ?>">Criar publicação <span aria-hidden="true">↗</span></a>
                </div>
            <?php else: ?>
                <div class="post-grid">
                    <?php foreach ($posts as $post): ?>
                        <article class="post-card">
                            <div class="card-top"><span class="card-icon" aria-hidden="true">✳</span><span>PUBLICAÇÃO · <?= esc(str_pad((string) $post->id, 2, '0', STR_PAD_LEFT)) ?></span></div>
                            <div class="card-body">
                                <time datetime="<?= esc(date('Y-m-d', strtotime($post->criado_em))) ?>"><?= esc(date('d/m/Y', strtotime($post->criado_em))) ?></time>
                                <h3><a href="<?= base_url('post/' . $post->id) ?>"><?= esc($post->titulo) ?></a></h3>
                                <p><?= esc(mb_strimwidth($post->conteudo, 0, 155, '…')) ?></p>
                            </div>
                            <a class="card-link" href="<?= base_url('post/' . $post->id) ?>">Ler publicação <span aria-hidden="true">↗</span></a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <footer class="site-footer"><div class="wrap footer-content"><strong>caderno<span>aberto</span> ✳</strong><span>Um blog para ideias que valem a leitura.</span></div></footer>
</body>
</html>
