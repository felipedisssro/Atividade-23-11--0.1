<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $post && isset($post->id) ? 'Editar' : 'Nova' ?> publicação | Caderno Aberto</title>
    <link rel="stylesheet" href="<?= base_url('blog.css') ?>">
</head>
<body>
    <header class="site-header"><div class="wrap header-content">
        <a class="brand" href="<?= base_url('/') ?>"><span class="brand-mark">✳</span> caderno<span>aberto</span></a>
        <nav aria-label="Navegação principal"><a href="<?= base_url('/') ?>">Ver blog</a><a class="nav-active" href="<?= base_url('painel/posts') ?>">Painel de posts</a></nav>
    </div></header>

    <main class="wrap form-page">
        <a class="back-link" href="<?= base_url('painel/posts') ?>">← Voltar ao painel</a>
        <p class="eyebrow">ÁREA DE GERENCIAMENTO</p>
        <h1><?= $post && isset($post->id) ? 'Editar publicação' : 'Nova publicação' ?><span class="heading-dot">.</span></h1>
        <p class="form-description">Escreva o título e o conteúdo da sua publicação.</p>

        <form class="editor-card" method="post">
            <?= csrf_field() ?>
            <?php if ($msg): ?><p class="form-error" role="alert"><?= esc($msg) ?></p><?php endif; ?>
            <div class="field"><label for="titulo">Título da publicação</label>
                <input type="text" id="titulo" name="titulo" maxlength="150" minlength="3" value="<?= esc($post->titulo ?? '') ?>" placeholder="Ex.: Um dia para lembrar" required>
                <small>Um título curto que conte sobre o seu texto.</small>
            </div>
            <div class="field"><label for="conteudo">Conteúdo</label>
                <textarea id="conteudo" name="conteudo" rows="12" minlength="3" placeholder="Comece a escrever sua história aqui..." required><?= esc($post->conteudo ?? '') ?></textarea>
                <small>As quebras de linha aparecem na publicação.</small>
            </div>
            <div class="form-actions"><a class="button button-light" href="<?= base_url('painel/posts') ?>">Cancelar</a><button class="button button-dark" type="submit">Salvar publicação <span aria-hidden="true">↗</span></button></div>
        </form>
    </main>
    <footer class="site-footer"><div class="wrap footer-content"><strong>caderno<span>aberto</span> ✳</strong><span>Um blog para ideias que valem a leitura.</span></div></footer>
</body>
</html>
