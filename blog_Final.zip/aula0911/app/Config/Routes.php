<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('/post/(:num)', 'Home::post/$1');

// Painel do blog (mesmo padrão usado nas rotas de Cursos).
$routes->get('/painel/posts', 'Posts::index');
$routes->match(['get', 'post'], '/painel/posts/inserir', 'Posts::inserir');
$routes->match(['get', 'post'], '/painel/posts/editar/(:num)', 'Posts::editar/$1');
$routes->post('/painel/posts/excluir/(:num)', 'Posts::excluir/$1');
$routes->get('/cursos/teste', 'Cursos::teste');
$routes->get('/cursos', 'Cursos::index');
$routes->get('/cursos/inserir', 'Cursos::inserir');

//rota para quando o formulário é submetido
$routes->post('/cursos/inserir', 'Cursos::inserir');

$routes->match(['get', 'post'], '/cursos/editar/(:num)', 'Cursos::editar/$1');

$routes->get('/cursos/excluir/(:num)', 'Cursos::excluir/$1');
