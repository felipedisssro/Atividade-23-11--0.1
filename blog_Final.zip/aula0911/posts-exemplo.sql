-- Opcional: execute após blog.sql para ver alguns posts na página inicial.
USE `aula0911`;

INSERT INTO `posts` (`titulo`, `conteudo`) VALUES
('Pequenas ideias, grandes projetos', 'Todo projeto começa com uma página em branco. Neste espaço vamos registrar ideias e compartilhar textos com quem gosta de descobrir coisas novas.'),
('Aprender algo novo todos os dias', 'Estudar programação é descobrir que errar faz parte. Cada tentativa ajuda a entender um pouco mais e a construir projetos melhores.'),
('Por que comecei a escrever', 'Às vezes, uma ideia pequena é suficiente para começar uma história. Este blog nasceu para compartilhar textos, experiências e coisas que aprendo no dia a dia.');
