-- Execute este arquivo no phpMyAdmin (aba SQL) ou pelo cliente MySQL.
-- Usa o mesmo banco aula0911 do projeto original do professor.
CREATE DATABASE IF NOT EXISTS `aula0911` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `aula0911`;

CREATE TABLE IF NOT EXISTS `posts` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `titulo` VARCHAR(150) NOT NULL,
    `conteudo` TEXT NOT NULL,
    `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
